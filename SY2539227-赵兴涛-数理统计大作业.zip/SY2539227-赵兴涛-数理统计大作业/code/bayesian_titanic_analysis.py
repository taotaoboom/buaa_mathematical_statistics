# 贝叶斯模型实现与推断
# 泰坦尼克号生还预测

import pymc as pm
import arviz as az
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os
import pickle
import json

# 设置matplotlib样式
plt.style.use('seaborn-v0_8-whitegrid')

# 确保图表文件夹存在
if not os.path.exists('bayesian_plots'):
    os.makedirs('bayesian_plots')

# 确保模型文件夹存在
if not os.path.exists('bayesian_models'):
    os.makedirs('bayesian_models')


def save_bayesian_model(model, trace, features, filepath='bayesian_models/titanic_model_v2.pkl'):
    """
    保存贝叶斯模型及其相关信息
    
    参数:
    - model: PyMC模型对象
    - trace: MCMC采样结果
    - features: 特征列表
    - filepath: 保存路径
    """
    # 保存模型相关信息
    model_info = {
        'features': features,
        'model_type': 'bayesian_logistic_regression',
        'created_at': pd.Timestamp.now().isoformat()
    }
    
    # 保存特征列表到json文件（方便后续加载）
    features_path = filepath.replace('.pkl', '_features.json')
    with open(features_path, 'w', encoding='utf-8') as f:
        json.dump(model_info, f, ensure_ascii=False, indent=2)
    
    # 提取trace中的关键信息（权重采样结果）
    # 避免使用可能有兼容性问题的netcdf格式
    weights_samples = trace.posterior['weights'].values
    trace_info = {
        'weights': weights_samples,
        'chain': trace.posterior.dims['chain'],
        'draw': trace.posterior.dims['draw']
    }
    
    # 保存trace信息到pickle文件
    trace_path = filepath.replace('.pkl', '_trace.pkl')
    with open(trace_path, 'wb') as f:
        pickle.dump(trace_info, f)
    
    print(f"\n模型信息已保存：")
    print(f"- 特征列表: {features_path}")
    print(f"- 采样结果: {trace_path}")


def load_bayesian_model(filepath='bayesian_models/titanic_model_v2.pkl'):
    """
    加载贝叶斯模型及其相关信息
    
    参数:
    - filepath: 模型保存路径
    
    返回:
    - features: 特征列表
    - trace: 包含权重采样结果的字典
    """
    # 加载特征列表
    features_path = filepath.replace('.pkl', '_features.json')
    with open(features_path, 'r', encoding='utf-8') as f:
        model_info = json.load(f)
    features = model_info['features']
    
    # 加载trace信息
    trace_path = filepath.replace('.pkl', '_trace.pkl')
    with open(trace_path, 'rb') as f:
        trace_info = pickle.load(f)
    
    print(f"\n模型已加载：")
    print(f"- 特征数量: {len(features)}")
    print(f"- 特征列表: {features}")
    print(f"- 采样链数: {trace_info['chain']}")
    print(f"- 每条链采样数: {trace_info['draw']}")
    print(f"- 权重采样形状: {trace_info['weights'].shape}")
    
    return features, trace_info


def create_model(features, X_data, y_data):
    """
    创建贝叶斯逻辑回归模型
    
    参数:
    - features: 特征列表
    - X_data: 特征数据
    - y_data: 目标变量
    
    返回:
    - model: PyMC模型对象
    """
    coords = {'features': features}
    
    with pm.Model(coords=coords) as model:
        # 定义Data容器（方便后续做后验预测）
        X = pm.Data("X_data", X_data)
        y = pm.Data("y_data", y_data)
        
        # 定义先验
        w = pm.Normal("weights", mu=0, sigma=10, dims="features")
        
        # 计算线性组合
        logit_p = pm.math.dot(X, w)
        
        # 定义似然函数
        obs = pm.Bernoulli("obs", logit_p=logit_p, observed=y)
    
    return model


def predict_with_bayesian_model(filepath, X_new):
    """
    使用保存的贝叶斯模型进行预测
    
    参数:
    - filepath: 模型保存路径
    - X_new: 新的特征数据
    
    返回:
    - pred_mean: 预测概率均值
    - pred_hdi: 预测概率HDI区间
    - pred_class: 预测类别（0/1）
    """
    # 加载模型信息和trace
    features, trace_info = load_bayesian_model(filepath)
    
    # 获取权重采样结果
    weights_samples = trace_info['weights']  # 形状: (chains, draws, features)
    
    # 计算线性组合 logit_p = X * w
    # weights_samples形状: (chains, draws, features)
    # X_new形状: (n_samples, features)
    # 需要计算每个样本的logit_p，形状应为: (chains, draws, n_samples)
    logit_p = np.einsum('cdf,nf->cdn', weights_samples, X_new)
    
    # 转换为概率 p = 1 / (1 + exp(-logit_p))
    pred_probs = 1 / (1 + np.exp(-logit_p))
    
    # 生成二分类预测样本（基于伯努利分布）
    np.random.seed(42)  # 确保结果可复现
    pred_samples = np.random.binomial(1, pred_probs)
    
    # 计算预测结果
    # 概率均值
    pred_mean = np.mean(pred_probs, axis=(0, 1))
    
    # 预测类别（阈值0.5）
    pred_class = (pred_mean > 0.5).astype(int)
    
    # 计算HDI区间
    # 将采样结果重塑为 (n_samples, chains*draws)
    pred_probs_reshaped = pred_probs.reshape(-1, pred_probs.shape[-1]).T
    pred_hdi = np.array([az.hdi(samples, hdi_prob=0.94) for samples in pred_probs_reshaped])
    
    return pred_mean, pred_hdi, pred_class


def main():
    # ==========================================
    # 1. 数据准备
    # ==========================================
    print("=== 数据准备 ===")

    # 读取处理后的数据集
    df_train = pd.read_csv('titanic_data/train_plus_feature.csv')
    df_test = pd.read_csv('titanic_data/test_plus_feature.csv')

    print("训练集基本信息：")
    print(df_train.info())
    print("\n训练集前5行：")
    print(df_train.head())

    # 特征列表（设置基准类别：男性、三等舱、南安普顿、普通先生）
    features = [
        'in_WCF', 'WCF_Died', 'WCF_Survived', 
        'family_size', 'group_size', 'is_alone', 'Age_category', 'fare_pp_sc',
        
        # 舱位 (基准: pclass_3) -> 只保留 1 和 2
        'pclass_1', 'pclass_2', 
        
        # 性别 (基准: sex_male) -> 只保留 female
        'sex_female', 
        
        # 港口 (基准: embarked_S) -> 只保留 C 和 Q
        'embarked_C', 'embarked_Q', 
        
        # 称谓 (基准: title_Mr) -> 剔除 Mr, 保留其他人
        'title_Master', 'title_Miss', 'title_Mrs', 'title_rare'
    ]

    # 目标变量
    target = 'Survived'

    # 转换为numpy数组
    X_train = df_train[features].values.astype(np.float32)
    y_train = df_train[target].values.astype(np.int32)

    print(f"\n特征矩阵形状：{X_train.shape}")
    print(f"目标变量形状：{y_train.shape}")

    # 设置坐标轴（coords）
    coords = {'features': features}

    print("\n数据准备完成！")

    # ==========================================
    # 2. 模型构建
    # ==========================================
    print("\n=== 模型构建 ===")

    with pm.Model(coords=coords) as model:
        # 定义Data容器（方便后续做后验预测）
        X_data = pm.Data("X_data", X_train)
        y_data = pm.Data("y_data", y_train)
        
        # 定义先验
        # w ~ N(0, 10^2)，对应公式中的设置
        w = pm.Normal("weights", mu=0, sigma=10, dims="features")
        
        # 计算线性组合
        logit_p = pm.math.dot(X_data, w)
        
        # 定义似然函数
        # 观测数据服从伯努利分布
        obs = pm.Bernoulli("obs", logit_p=logit_p, observed=y_data)
        
        # MCMC 推断
        print("开始 MCMC 采样...")
        trace = pm.sample(draws=2000,      # 采样次数
                        tune=1000,       # 预热次数
                        chains=4,        # 链数
                        target_accept=0.9, # 提高接受率以避免发散
                        return_inferencedata=True,
                        random_seed=42,
                        progressbar=True)  # 显示进度条

    print("\n模型构建与采样完成！")

    # ==========================================
    # 3. 收敛性诊断
    # ==========================================
    print("\n=== 收敛性诊断 ===")

    # (1) 查看摘要统计量 (R_hat, ESS)
    summary_df = az.summary(trace, var_names=["weights"])
    print("\n参数摘要统计：")
    print(summary_df)

    # 保存摘要统计到文件
    summary_df.to_csv('bayesian_plots/parameter_summary_v2.csv')

    # (2) 绘制迹图 (Trace Plot)
    print("\n绘制迹图...")
    # 让az.plot_trace()自动创建适合的子图，而不是手动指定axes参数
    az.plot_trace(trace, var_names=["weights"], compact=True)
    plt.tight_layout()
    plt.savefig('bayesian_plots/trace_plot_v2.png', dpi=300, bbox_inches='tight')
    plt.close()

    # (3) 检查R_hat是否满足收敛条件
    r_hat_max = summary_df['r_hat'].max()
    ess_min = summary_df['ess_bulk'].min()

    print(f"\n收敛性指标：")
    print(f"最大R_hat值：{r_hat_max:.4f}")
    print(f"最小ESS值：{ess_min:.0f}")

    if r_hat_max <= 1.01:
        print("✅ R_hat指标满足收敛条件（≤1.01）")
    else:
        print("❌ R_hat指标不满足收敛条件（>1.01）")

    if ess_min > 400:
        print("✅ ESS指标满足收敛条件（>400）")
    else:
        print("⚠️ ESS指标较低（≤400），建议增加采样次数")

    # ==========================================
    # 4. 后验结果分析
    # ==========================================
    print("\n=== 后验结果分析 ===")

    # (1) 绘制森林图 (Forest Plot) - 最适合放进报告里的图
    print("\n绘制森林图...")
    plt.figure(figsize=(10, 12))
    az.plot_forest(trace, var_names=["weights"], kind='ridgeplot', 
                combined=True, hdi_prob=0.94, colors='blue')
    plt.axvline(x=0, color='r', linestyle='--') # 添加 0 线辅助判断
    plt.title("Posterior Distributions of Feature Weights (94% HDI)")
    plt.savefig('bayesian_plots/forest_plot_v2.png', dpi=300, bbox_inches='tight')
    plt.close()

    # (2) 特征影响分析
    print("\n特征影响分析：")
    print("================")

    # 计算特征权重的均值和HDI
    feature_means = summary_df['mean'].values
    feature_hdi_lower = summary_df['hdi_3%'].values
    feature_hdi_upper = summary_df['hdi_97%'].values

    # 排序特征（按绝对值大小）
    sorted_indices = np.argsort(np.abs(feature_means))[::-1]

    for i in sorted_indices:
        feature = features[i]
        mean = feature_means[i]
        hdi_lower = feature_hdi_lower[i]
        hdi_upper = feature_hdi_upper[i]
        
        # 判断是否显著（HDI不包含0）
        is_significant = hdi_lower * hdi_upper > 0
        significance_marker = "*" if is_significant else ""
        
        print(f"{feature}: 均值 = {mean:.4f}, 94% HDI = [{hdi_lower:.4f}, {hdi_upper:.4f}]{significance_marker}")

    # ==========================================
    # 5. 后验预测
    # ==========================================
    print("\n=== 后验预测 ===")

    # (1) 预测某一乘客 - 选择训练集中的第一个样本
    print("\n预测训练集中第一个样本的生还概率：")
    print("样本特征：")
    print(df_train[features].iloc[0].to_dict())
    print(f"实际生还情况：{df_train[target].iloc[0]}")

    # 生成后验预测
    with model:
        # 生成训练集上的后验预测，用于评估模型整体拟合度
        ppc = pm.sample_posterior_predictive(trace, var_names=["obs"])

    # 计算第一个样本的预测分布（在概率尺度上）
    # 提取所有链的权重样本 (4 * 1000, n_features)
    posterior_weights = trace.posterior['weights'].values.reshape(-1, len(features))
    
    # 获取第一个样本的特征 (n_features, )
    sample_X = X_train[0]
    
    # 1. 计算 Logit: z = w * x
    posterior_logits = np.dot(posterior_weights, sample_X)
    
    # 2. 转换为概率: p = 1 / (1 + e^-z)
    posterior_probs = 1 / (1 + np.exp(-posterior_logits))
    
    # 3. 计算概率的均值和HDI
    mean_prob = np.mean(posterior_probs)
    hdi_prob_result = az.hdi(posterior_probs, hdi_prob=0.94)
    
    print(f"\n预测生还概率：")
    print(f"均值：{mean_prob:.4f}")
    print(f"94% HDI (概率空间)：[{hdi_prob_result[0]:.4f}, {hdi_prob_result[1]:.4f}]")

    # (2) 计算模型整体准确率
    print("\n计算模型整体准确率：")
    pred_mean = ppc.posterior_predictive["obs"].mean(dim=("chain", "draw")).values
    predicted_class = (pred_mean > 0.5).astype(int)
    accuracy = (predicted_class == y_train).mean()
    print(f"训练集贝叶斯模型准确率: {accuracy:.4f}")
    
    # (3) 计算ROC曲线和AUC
    print("\n计算ROC曲线和AUC...")
    from sklearn.metrics import roc_curve, auc
    
    # 使用后验预测的概率均值计算ROC和AUC
    fpr, tpr, _ = roc_curve(y_train, pred_mean)
    roc_auc = auc(fpr, tpr)
    print(f"训练集AUC值: {roc_auc:.4f}")
    
    # 绘制并保存ROC曲线
    def plot_roc_curve(fpr, tpr, roc_auc, save_path='bayesian_plots/roc_curve.png'):
        """
        绘制ROC曲线并保存
        
        参数:
        - fpr: 假正例率
        - tpr: 真正例率
        - roc_auc: AUC值
        - save_path: 保存路径
        """
        plt.figure(figsize=(8, 8))
        plt.plot(fpr, tpr, color='darkorange', lw=2, 
                 label=f'ROC curve (AUC = {roc_auc:.4f})')
        plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
        plt.xlim([0.0, 1.0])
        plt.ylim([0.0, 1.05])
        plt.xlabel('False Positive Rate')
        plt.ylabel('True Positive Rate')
        plt.title('Receiver Operating Characteristic (ROC) Curve')
        plt.legend(loc="lower right")
        plt.grid(True)
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        plt.close()
        print(f"ROC曲线已保存到: {save_path}")
    
    # 调用函数绘制ROC曲线
    plot_roc_curve(fpr, tpr, roc_auc, 'bayesian_plots/roc_curve_v2.png')

    # ==========================================
    # 6. 测试集预测与Submission文件生成
    # ==========================================
    print("\n=== 测试集预测与Submission文件生成 ===")

    # 处理测试集特征
    X_test = df_test[features].values.astype(np.float32)
    passenger_ids = df_test['PassengerId'].values

    print(f"\n测试集特征矩阵形状：{X_test.shape}")
    print(f"测试集样本数量：{len(passenger_ids)}")

    # 使用模型对测试集进行预测
    with model:
        # 更新模型的X_data为测试集特征，同时更新y_data为与测试集大小匹配的数组
        # 这里y_data的值不会影响预测结果，只是为了匹配维度和数据类型
        pm.set_data({
            "X_data": X_test,
            "y_data": np.zeros(len(X_test), dtype=np.int32)  # 使用int32类型，与原始数据类型匹配
        })
        
        # 生成测试集上的后验预测
        ppc_test = pm.sample_posterior_predictive(trace, var_names=["obs"])

    # 计算每个测试样本的预测概率均值
    test_pred_mean = ppc_test.posterior_predictive["obs"].mean(dim=("chain", "draw")).values
    
    # 根据概率均值生成0/1预测结果（阈值0.5）
    test_pred = (test_pred_mean > 0.5).astype(int)

    print(f"\n测试集预测结果统计：")
    print(f"- 预测生还人数：{test_pred.sum()}")
    print(f"- 预测死亡人数：{len(test_pred) - test_pred.sum()}")

    # 生成Submission文件
    submission = pd.DataFrame({
        "PassengerId": passenger_ids,
        "Survived": test_pred
    })

    # 保存Submission文件
    submission.to_csv('titanic_data/submission_v2.csv', index=False)
    print(f"\nSubmission文件已生成：titanic_data/submission_v2.csv")
    print(f"文件包含 {len(submission)} 条记录")
    print(f"前5行内容：")
    print(submission.head())

    # ==========================================
    # 7. 模型保存
    # ==========================================
    print("\n=== 模型保存 ===")

    # 使用自定义函数保存模型（避免netcdf兼容性问题）
    save_bayesian_model(model, trace, features, 'bayesian_models/titanic_model_v2.pkl')

    print("\n模型已成功保存到bayesian_models文件夹！")

    # ==========================================
    # 7. 生成markdown报告
    # ==========================================
    print("\n=== 生成markdown报告 ===")

    report_content = f"""# 泰坦尼克号贝叶斯模型分析报告 (改进版)

## 1. 模型概述

本报告使用贝叶斯方法对泰坦尼克号乘客生还情况进行预测和分析。模型基于逻辑回归框架，使用PyMC进行贝叶斯推断，通过MCMC方法采样后验分布。

### 1.1 数据来源

数据集来自处理后的`titanic_data/train_plus_feature.csv`，包含17个特征和891个样本。

### 1.2 模型结构

- **先验分布**：权重参数 $w$ 服从均值为0，标准差为10的正态分布
- **似然函数**：伯努利分布，使用logit链接函数
- **采样方法**：MCMC采样，4条链，每条链2000次采样，1000次预热

### 1.3 特征选择

特征选择遵循了**避免多重共线性**的原则，为每个类别特征设置了基准组：

- **舱位**：基准组为三等舱 (`pclass_3`)，保留 `pclass_1` 和 `pclass_2`
- **性别**：基准组为男性 (`sex_male`)，保留 `sex_female`
- **登船港口**：基准组为南安普顿 (`embarked_S`)，保留 `embarked_C` 和 `embarked_Q`
- **称谓**：基准组为普通先生 (`title_Mr`)，保留 `title_Master`、`title_Miss`、`title_Mrs` 和 `title_rare`

## 2. 收敛性诊断

### 2.1 数值诊断

| 指标 | 值 | 结论 |
|------|-----|------|
| 最大R_hat | {r_hat_max:.4f} | {'✅ 满足收敛条件（≤1.01）' if r_hat_max <= 1.01 else '❌ 不满足收敛条件（>1.01）'} |
| 最小ESS | {ess_min:.0f} | {'✅ 满足收敛条件（>400）' if ess_min > 400 else '⚠️ 较低（≤400）'} |

### 2.2 图形诊断

![迹图](bayesian_plots/trace_plot_v2.png)

## 3. 后验结果分析

### 3.1 特征权重分布

![森林图](bayesian_plots/forest_plot_v2.png)

### 3.2 特征影响分析

| 特征 | 均值 | 94% HDI | 显著性 |
|------|------|---------|--------|
"""

    # 添加特征影响分析表格
    for i in sorted_indices:
        feature = features[i]
        mean = feature_means[i]
        hdi_lower = feature_hdi_lower[i]
        hdi_upper = feature_hdi_upper[i]
        is_significant = hdi_lower * hdi_upper > 0
        significance = "*" if is_significant else ""
        
        report_content += f"| {feature} | {mean:.4f} | [{hdi_lower:.4f}, {hdi_upper:.4f}] | {significance} |\n"

    # 继续添加报告内容
    report_content += f"""\n*注：* 表示特征影响显著（94% HDI不包含0）

## 4. 预测结果

### 4.1 单个样本预测

选择训练集中第一个样本进行预测：

```
{df_train[features].iloc[0].to_dict()}
```

- 实际生还情况：{df_train[target].iloc[0]}
- 预测生还概率均值：{mean_prob:.4f}
- 94% HDI（概率空间）：[{hdi_prob_result[0]:.4f}, {hdi_prob_result[1]:.4f}]

### 4.2 模型整体表现

- 训练集准确率：{accuracy:.4f}
- 训练集AUC值：{roc_auc:.4f}

#### ROC曲线

ROC曲线展示了模型在不同阈值下的真正例率（TPR）和假正例率（FPR）之间的权衡：

![ROC曲线](bayesian_plots/roc_curve_v2.png)

## 5. 图表与数据文件

所有图表和数据文件均保存在`bayesian_plots`文件夹中：
- `trace_plot_v2.png`：MCMC采样迹图
- `forest_plot_v2.png`：特征权重后验分布森林图
- `roc_curve_v2.png`：ROC曲线
- `parameter_summary_v2.csv`：参数摘要统计
- `trace.nc`：MCMC采样结果
- `ppc.nc`：后验预测结果"""

    # 保存报告
    with open('bayesian_titanic_results_v2.md', 'w', encoding='utf-8') as f:
        f.write(report_content)

    print("\n报告生成完成：bayesian_titanic_results_v2.md")
    print("\n=== 分析完成 ===")


def perform_counterfactual_analysis(model_path='bayesian_models/titanic_model_v2.pkl', 
                                    data_path='titanic_data/train_plus_feature.csv'):
    """
    执行反事实推断实验：如果 Braund 先生是女性，生存率分布如何变化？
    """
    print("\n=== 开始反事实推断实验 (Counterfactual Inference) ===")
    
    # 1. 加载模型和数据
    features, trace_info = load_bayesian_model(model_path)
    df_train = pd.read_csv(data_path)
    
    # 2. 获取 Braund 先生的原始数据 (Index 0)
    # 注意：必须确保 X_braund 的特征顺序与训练时完全一致
    braund_series = df_train.iloc[0][features]
    X_braund = braund_series.values.astype(np.float32)
    
    print(f"目标乘客: PassengerId {df_train.iloc[0]['PassengerId']}")
    # 只显示实际存在于特征列表中的特征
    display_features = ['sex_female', 'pclass_1', 'pclass_2', 'Age_category', 'fare_pp_sc']
    print("原始特征状态: ")
    print(braund_series[display_features])
    
    # 3. 准备后验权重矩阵
    # 形状: (n_chains * n_draws, n_features)
    weights = trace_info['weights']
    weights_flat = weights.reshape(-1, len(features))
    
    # ==========================================
    # 场景 A: 现实情况 (男性)
    # ==========================================
    # 计算 Logit: z = w * x
    logits_original = np.dot(weights_flat, X_braund)
    # Sigmoid 变换: p = 1 / (1 + e^-z)
    probs_original = 1 / (1 + np.exp(-logits_original))
    
    # 计算统计量
    mean_orig = np.mean(probs_original)
    hdi_orig = az.hdi(probs_original, hdi_prob=0.94)
    
    print(f"\n[现实场景] 男性身份:")
    print(f"生存概率均值: {mean_orig:.4%}")
    print(f"94% HDI: [{hdi_orig[0]:.4%}, {hdi_orig[1]:.4%}]")
    
    # ==========================================
    # 场景 B: 反事实情况 (修改为女性)
    # ==========================================
    # 复制特征向量
    X_counterfactual = X_braund.copy()
    
    # 找到 'sex_female' 特征的索引
    idx_sex_female = features.index('sex_female')
    
    # 修改特征：将 0 (男性) 改为 1 (女性)
    # 注意：我们使用的是 One-Hot 编码且剔除了基准组 sex_male。
    # 所以只要把 sex_female 设为 1，就代表是女性；设为 0，就代表是基准组(男性)。
    X_counterfactual[idx_sex_female] = 1.0 
    
    # 重新计算分布
    logits_cf = np.dot(weights_flat, X_counterfactual)
    probs_cf = 1 / (1 + np.exp(-logits_cf))
    
    # 计算统计量
    mean_cf = np.mean(probs_cf)
    hdi_cf = az.hdi(probs_cf, hdi_prob=0.94)
    
    print(f"\n[反事实场景] 假设为女性 (其他条件不变):")
    print(f"生存概率均值: {mean_cf:.4%}")
    print(f"94% HDI: [{hdi_cf[0]:.4%}, {hdi_cf[1]:.4%}]")
    
    # ==========================================
    # 可视化对比 (可选，生成一张很有说服力的图)
    # ==========================================
    plt.figure(figsize=(10, 6))
    sns.kdeplot(probs_original, fill=True, label='Original (Male)', color='blue')
    sns.kdeplot(probs_cf, fill=True, label='Counterfactual (Female)', color='orange')
    plt.title('Counterfactual Inference: Impact of Gender on Survival Probability')
    plt.xlabel('Predicted Survival Probability')
    plt.ylabel('Density')
    plt.legend()
    plt.xlim(0, 1)
    plt.savefig('bayesian_plots/counterfactual_analysis.png', dpi=300)
    print("\n可视化结果已保存至: bayesian_plots/counterfactual_analysis.png")


# 示例：如何使用独立的预测函数
if __name__ == '__main__':
    import sys
    # 如果命令行参数包含"counterfactual"，则执行反事实分析
    if len(sys.argv) > 1 and sys.argv[1] == 'counterfactual':
        perform_counterfactual_analysis()
    # 如果命令行参数包含"predict"，则执行预测示例
    elif len(sys.argv) > 1 and sys.argv[1] == 'predict':
        print("=== 预测示例 ===")
        
        # 示例1：使用保存的模型对测试集进行预测
        print("\n1. 加载测试集数据...")
        df_test = pd.read_csv('titanic_data/test_plus_feature.csv')
        
        # 加载模型并获取特征列表
        features, _ = load_bayesian_model('bayesian_models/titanic_model_v2.pkl')
        
        # 准备测试集特征
        X_test = df_test[features].values.astype(np.float32)
        passenger_ids = df_test['PassengerId'].values
        
        print(f"\n2. 测试集包含 {len(X_test)} 个样本")
        print(f"   特征数量: {X_test.shape[1]}")
        
        # 使用模型进行预测
        print("\n3. 开始预测...")
        pred_mean, pred_hdi, pred_class = predict_with_bayesian_model(
            'bayesian_models/titanic_model_v2.pkl', X_test
        )
        
        print(f"\n4. 预测结果统计：")
        print(f"   - 预测生还人数: {pred_class.sum()}")
        print(f"   - 预测死亡人数: {len(pred_class) - pred_class.sum()}")
        
        # 显示前5个样本的预测结果
        print(f"\n5. 前5个样本的预测结果：")
        for i in range(5):
            print(f"   样本 {passenger_ids[i]}: 生还概率 = {pred_mean[i]:.4f}, "
                  f"94% HDI = [{pred_hdi[i][0]:.4f}, {pred_hdi[i][1]:.4f}], "
                  f"预测结果 = {'生还' if pred_class[i] == 1 else '死亡'}")
        
    else:
        # 否则执行完整的训练和分析流程
        main()