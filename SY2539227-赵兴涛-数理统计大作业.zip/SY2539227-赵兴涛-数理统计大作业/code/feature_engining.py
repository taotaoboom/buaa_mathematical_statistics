# libraries
import numpy as np 
import pandas as pd 
import os
import matplotlib.pyplot as plt
import seaborn as sns
import re
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler

from sklearn.model_selection import KFold
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import GridSearchCV

from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import Perceptron
from sklearn.linear_model import SGDClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC, LinearSVC
from sklearn.naive_bayes import GaussianNB, BernoulliNB, MultinomialNB
from sklearn.ensemble import BaggingClassifier
from sklearn.model_selection import StratifiedKFold
from sklearn.ensemble import GradientBoostingClassifier
from xgboost import XGBClassifier
from sklearn.ensemble import HistGradientBoostingClassifier
from lightgbm import LGBMClassifier
from sklearn.ensemble import AdaBoostClassifier
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.linear_model import RidgeClassifier 


train = pd.read_csv('titanic/train.csv')
test = pd.read_csv('titanic/test.csv')
alldata = pd.concat([train, test], axis = 0, ignore_index = True)

# engineering: Title
alldata['title'] = alldata.Name.apply(lambda x: re.search(r',\s(.+?)\.', x).group(1))
# Reclassify titles
alldata.loc[alldata.title.isin(['Ms', 'Mlle']), 'title'] = 'Miss'
alldata.loc[alldata.title.isin(['Mme']), 'title'] = 'Mrs'
# Rare category
rare = ['Major', 'Lady', 'Sir', 'Don', 'Capt', 'the Countess', 'Jonkheer', 'Dona', 'Dr', 'Rev', 'Col']
alldata.loc[alldata.title.isin(rare), 'title'] = 'rare'
# print(alldata.title.value_counts())

# We’ll be engineering the following features:
# * `in_WCF`: This feature is based on the survival rate of passengers with the same surname. If the passenger is a woman or child, this feature is set to 1; otherwise, it’s set to 0.
# * `WCF_Survived`: If the passenger is in a WCF group with a survival rate greater than 50%, this feature is set to 1; otherwise, it’s set to 0.
# * `WCF_Died`: If the passenger is in a WCF group with a survival rate less than 50%, this feature is set to 1; otherwise, it’s set to 0.
# Surnames
alldata['surname'] = alldata.Name.apply(lambda x: re.search(r'^(.+?)\,', x).group(1))
### Feature that contains surnames for WCF groups
alldata['surname_WCF'] = alldata.surname

# Take out adult males but we keep boys (Master)
alldata.loc[((alldata.Sex == 'male') & (alldata.title == 'Mr'))|
             ((alldata.Sex == 'male') & (alldata.title == 'rare')), 'surname_WCF'] = np.nan

# WCF_count counts the number of passenger for each surname group (in_WCF)
alldata['WCF_count'] = alldata.groupby('surname_WCF')['surname_WCF'].transform('count')
alldata.loc[(alldata.WCF_count < 2.0 ), 'surname_WCF'] = np.nan

alldata.loc[(alldata.WCF_count >= 2.0), 'in_WCF'] = 1
alldata.loc[(alldata.WCF_count < 2.0 ), 'in_WCF'] = 0

# WCF_Survived & WCF_Died 
for surname in alldata.surname_WCF.unique():
    surv_rate = np.mean(alldata.loc[alldata.surname_WCF == surname, 'Survived'])
    if surv_rate > 0.5:
        alldata.loc[alldata.surname_WCF == surname, 'WCF_Survived'] = 1
    else:
        alldata.loc[alldata.surname_WCF == surname, 'WCF_Died'] = 1
# Fillna in the new features 
alldata[['in_WCF', 'WCF_Survived', 'WCF_Died']] = alldata[['in_WCF', 'WCF_Survived', 'WCF_Died']].fillna(0)
# Drop intermediate features no longer needed
alldata.drop(columns=['Name', 'surname', 'surname_WCF', 'WCF_count'], axis = 1, inplace = True)


# engineering: family_size, ticket_group_count, groupsize, and is_alone features
# print(f"The number of passengers sharing tickets is: {len(alldata) - len(alldata.Ticket.unique())}")
alldata['family_size'] = alldata.SibSp + alldata.Parch + 1
alldata['ticket_group_count'] = alldata.groupby('Ticket')['Ticket'].transform('count')
# print(f"Number of passenger that match family_size and ticket_group_count is: {len(alldata[alldata.family_size == alldata.ticket_group_count])}")
# print(f"There's a mismatch of {len(alldata) - len(alldata[alldata.family_size == alldata.ticket_group_count])}")
alldata['group_size'] = alldata[['family_size', 'ticket_group_count']].max(axis = 1)
alldata['is_alone'] = alldata.group_size.apply(lambda x: 1 if x == 1 else 0)

# transformation `Pclass` & `fare`
alldata['fare_pp'] = alldata.Fare / alldata.ticket_group_count
alldata.drop('Fare', axis = 1, inplace = True)
alldata.drop('Ticket', axis = 1, inplace = True)
alldata.loc[alldata[alldata.fare_pp.isna()].index, 'fare_pp'] = alldata.groupby('Pclass')['fare_pp'].median()[3]
# after transformation
fig, axs = plt.subplots(nrows = 3, ncols = 1, figsize = (8, 15))
colors = ['green', 'blue', 'black']
for i in range(3):
    alldata.loc[alldata.Pclass == i + 1, 'fare_pp'].hist(alpha = 0.8, ax = axs[i], bins = 50, color = colors[i])
    axs[i].set_title(f"Distribution of Fare in the Pclass {i+1}")
    axs[i].set_xlabel('Number of Passengers')
    axs[i].set_ylabel('Fare')
# Visualizing the distribution of Fare in each Pclass
# plt.savefig('fare_pp.png')
plt.clf()
#plt.show()  

# Categorizing Passengers by Age
# train age and test age 
train_age = alldata[alldata.Age.notnull()].copy()
test_age = alldata[alldata.Age.isna()].copy()
# fit to the data
kmeans = KMeans(n_clusters = 4, random_state = 41)
labels_pred = kmeans.fit_predict(train_age[['Age']])
# flatten (1D) array of the cluster centers from a fitted k-means clustering
kmeans.cluster_centers_.flatten()
# indices that would sort the array in ascending order
np.argsort(kmeans.cluster_centers_.flatten())
# dictionary to label the clusters
label_dict = {label: v for v, label in enumerate(np.argsort(kmeans.cluster_centers_.flatten()))}
labels = [label_dict[label] for label in labels_pred]
train_age['Age_category'] = labels
# Visualizing new age clusters
# 画“年龄按聚类类别分布”的横向散点图（strip plot）
# y='Age'：纵轴放原始年龄数值
# hue='Age_category'：用不同颜色区分 4 个聚类类别
# jitter=0.8：给点加 0.8 水平抖动，避免重叠
# height=5：图高 5 英寸
# aspect=1.2：宽高比 1.2，决定图宽
g = sns.catplot(y='Age', data=train_age, hue='Age_category', jitter=0.8, height=5, aspect=1.2)
g.fig.suptitle('Passenger Age Categories', y=1.02, fontsize=10)  # 调整标题位置避免遮挡
# g.savefig('age_category.png')
# 清空plt
plt.clf()
#plt.show()

alldata = pd.concat([alldata, train_age.Age_category], axis = 1)
alldata.drop(['Cabin', 'Age'], axis = 1, inplace = True)


# ### Missing values for Embarked
alldata.loc[alldata.Embarked.isnull(), 'Embarked'] = 'S'

# Preprocessing - OneHotEncoding
preprocessing_dummies = pd.get_dummies(alldata[['Pclass', 'Sex', 'Embarked', 'title']],
               columns = ['Pclass', 'Sex', 'Embarked', 'title'],
               prefix = ['pclass', 'sex', 'embarked', 'title'],
               drop_first= False
              )
alldata = pd.concat([alldata, preprocessing_dummies], axis = 1)
alldata.drop(['Pclass', 'Sex', 'Embarked', 'title'], axis = 1, inplace = True)

# ###年龄类别——缺失值的填补,现在是填充Age_category特性中缺失值的时候了。我们选择SVC是因为它在这个数据集上运行得很好。
X = alldata.loc[alldata.Age_category.notnull(), ['SibSp', 'Parch', 'in_WCF', 'WCF_Died', 'WCF_Survived',
       'family_size', 'ticket_group_count', 'group_size', 'is_alone',
       'fare_pp', 'pclass_1', 'pclass_2', 'pclass_3',
       'sex_female', 'sex_male', 'embarked_C', 'embarked_Q', 'embarked_S',
       'title_Master', 'title_Miss', 'title_Mr', 'title_Mrs', 'title_rare']].copy()
y = alldata.loc[alldata.Age_category.notnull(), 'Age_category'].copy()
scaler = StandardScaler()
fare_pp_sc_X = pd.DataFrame(scaler.fit_transform(X[['fare_pp']]), columns=['fare_pp_sc'], index = X.index)
X = pd.concat([X, fare_pp_sc_X], axis = 1).drop('fare_pp', axis=1)
# # Testing multiple model to impute age
# Fiting GBC on X_train_a
svc = SVC(random_state = 41)
svc.fit(X, y)
X_test_cat_age_imp =  alldata.loc[alldata.Age_category.isna(), ['SibSp', 'Parch', 'in_WCF', 'WCF_Died', 'WCF_Survived',
       'family_size', 'ticket_group_count', 'group_size', 'is_alone',
       'fare_pp', 'pclass_1', 'pclass_2', 'pclass_3',
       'sex_female', 'sex_male', 'embarked_C', 'embarked_Q', 'embarked_S',
       'title_Master', 'title_Miss', 'title_Mr', 'title_Mrs', 'title_rare']]
# scaling fare per passenger X_test_imputation
fare_pp_sc_test_imputation = pd.DataFrame(scaler.transform(X_test_cat_age_imp[['fare_pp']]), columns =['fare_pp_sc'], index = X_test_cat_age_imp.index)
X_test_cat_age_imp = pd.concat([X_test_cat_age_imp, fare_pp_sc_test_imputation], axis = 1).drop('fare_pp', axis=1)
imputation_cat_age = svc.predict(X_test_cat_age_imp)
alldata.loc[alldata.Age_category.isnull(), 'Age_category'] = imputation_cat_age

# # Clean and ready to use Train and Test split
train_clean = alldata.loc[alldata.Survived.notnull()].copy()
test_clean = alldata.loc[alldata.Survived.isnull()].drop('Survived', axis = 1).copy()

# # Split Independent and dependent variables from train_clean
X = train_clean
y = train_clean.Survived
scaler = StandardScaler()
X_fare_sc = pd.DataFrame(scaler.fit_transform(X[['fare_pp']]), columns=['fare_pp_sc'], index = X.fare_pp.index)
test_clean_fare_sc = pd.DataFrame(scaler.transform(test_clean[['fare_pp']]), columns=['fare_pp_sc'], index = test_clean.fare_pp.index)
# final data
X = pd.concat([X, X_fare_sc], axis = 1).drop('fare_pp', axis = 1)
test_clean = pd.concat([test_clean, test_clean_fare_sc], axis = 1).drop('fare_pp', axis = 1)
print(X.info())
# 保存处理后的训练集和测试集
X.to_csv('titanic/train_plus_feature.csv', index=False)
test_clean.to_csv('titanic/test_plus_feature.csv', index=False)


features = ['in_WCF', 'WCF_Died', 'WCF_Survived', 'family_size', 'group_size', 'is_alone', 'Age_category',
       'pclass_1', 'pclass_2', 'pclass_3', 'sex_female', 'sex_male',
       'embarked_C', 'embarked_Q', 'embarked_S', 'title_Master', 'title_Miss',
       'title_Mr', 'title_Mrs', 'title_rare', 'fare_pp_sc']
X = X[features].copy()
models = {
    'Logistic Regression': LogisticRegression(max_iter = 500, random_state = 41),
    'Random Forest Classifier': RandomForestClassifier(random_state = 41),
    'Perceptron': Perceptron(random_state = 41),
    'SGD Classifier': SGDClassifier(random_state = 41),
    'Decision Tree Classifier': DecisionTreeClassifier(random_state = 41),
    'K-Nearest Neighbors Classifier': KNeighborsClassifier(),
    'Support Vector Machines (SVC)': SVC(random_state = 41),
    'Gaussian Naive Bayes': GaussianNB(),  # 高斯朴素贝叶斯,效果最好
    # 'Bernoulli Naive Bayes': BernoulliNB(),  # 伯努利朴素贝叶斯 
    # 'Multinomial Naive Bayes': MultinomialNB(),  # 多项式朴素贝叶斯 
    'Bagging Classifier' : BaggingClassifier(random_state = 41),
    "Gradient Boosting": GradientBoostingClassifier(random_state=41),
    'XGBC' : XGBClassifier(random_state = 41),
    'Hist Gradient Boosting Classifier' : HistGradientBoostingClassifier(random_state = 41),
    # 'LGBM' : LGBMClassifier(random_state = 41),
    'ADABoost' : AdaBoostClassifier(random_state=41),
    'ExtraTreesClassifier' : ExtraTreesClassifier(random_state = 41)
}
accuracy_scores = {}

# StratifiedKFold 参数说明：
# n_splits=5：将训练集划分为 5 折，每次用 4 折训练，1 折验证    
# random_state=41：随机种子，保证每次划分结果可复现
# shuffle=True：划分前先把数据打乱，避免顺序带来的偏差
skf = StratifiedKFold(n_splits=5, random_state=41, shuffle=True)
for name, model in models.items():
        cv_score = cross_val_score(model, X, y, cv = skf)
        accuracy_scores[name] = cv_score    
        print(f"Using the model {name} CV Av Accuracy Scores is {np.mean(accuracy_scores[name])*100:.2f}% and the std is {np.std(accuracy_scores[name])*100:.2f}%")
data = [value for value in accuracy_scores.values()]
labels = list(accuracy_scores.keys())
plt.figure(figsize=(10, 8))  # 调整画布尺寸
# 参数说明：
# data: 每个模型5折交叉验证的准确率列表组成的列表
# labels: 模型名称，用于y轴显示
# showmeans=True: 在箱线图中用圆点标出平均值
# vert=False: 水平绘制箱线图（横向）
plt.boxplot(data, labels=labels, showmeans=True, vert=False)
plt.xlabel('Accuracy')
plt.tight_layout()  # 自动调整子图参数，避免标签遮挡
# plt.savefig('different_model_accuracy_scores.png')


