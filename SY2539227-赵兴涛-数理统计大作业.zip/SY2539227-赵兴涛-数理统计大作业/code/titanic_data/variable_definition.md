基于原始特征，最终决定使用以下 8组，共21 个特征来构建贝叶斯模型。

以下是这些特征的具体含义及构建来源总结：

### 1. “妇女儿童优先”组特征 (WCF Features)
*   **`in_WCF`**：是否属于“妇女儿童”同姓氏组。
    *   *定义*：如果乘客是女性或儿童（头衔为 Master），且其姓氏在船上出现 2 次及以上，则为 1，否则为 0。
*   **`WCF_Survived`**：所在 WCF 组是否大概率**幸存**。
    *   *定义*：该乘客同姓氏 WCF 组的平均存活率 > 0.5。
*   **`WCF_Died`**：所在 WCF 组是否大概率**遇难**。
    *   *定义*：该乘客同姓氏 WCF 组的平均存活率 ≤ 0.5。

### 2. 团体/家庭规模特征 (Group Size Features)
*   **`family_size`**：法定家庭规模。
    *   *定义*：`SibSp` (兄弟姐妹/配偶) + `Parch` (父母/子女) + 1 (自己)。
*   **`group_size`**：实际团体规模（修正版）。
    *   *定义*：取 `family_size` 和 `ticket_group_count`（共用同一票号的人数）中的最大值。这能捕捉到非亲属关系的旅行团体（如带仆人或朋友）。
*   **`is_alone`**：是否独自一人。
    *   *定义*：如果 `group_size` 为 1，则为 1，否则为 0。

### 3. 年龄特征 (Age Feature)
*   **`Age_category`**：年龄聚类类别。
    *   *定义*：原始年龄经过 K-Means 聚类后的标签（0, 1, 2, 3）。
    *   *注意*：对于原始数据中年龄缺失的样本，该特征是通过训练一个 SVC 模型预测填补的。

### 4. 票价特征 (Fare Feature)
*   **`fare_pp_sc`**：标准化后的人均票价。
    *   *定义*：
        1.  计算 `fare_pp` = `Fare` / `ticket_group_count`（总票价除以共用人数）。
        2.  缺失值用同 `Pclass` 的中位数填充。
        3.  最后使用 `StandardScaler` 进行标准化处理。

### 5. 船舱等级 (One-Hot Encoded Pclass)
*   **`pclass_1`**：是否是一等舱 (1/0)。
*   **`pclass_2`**：是否是二等舱 (1/0)。
*   **`pclass_3`**：是否是三等舱 (1/0)。

### 6. 性别 (One-Hot Encoded Sex)
*   **`sex_female`**：是否是女性 (1/0)。
*   **`sex_male`**：是否是男性 (1/0)。

### 7. 登船港口 (One-Hot Encoded Embarked)
*   **`embarked_C`**：是否从 Cherbourg 登船 (1/0)。
*   **`embarked_Q`**：是否从 Queenstown 登船 (1/0)。
*   **`embarked_S`**：是否从 Southampton 登船 (1/0)。

### 8. 称谓/头衔 (One-Hot Encoded Title)
*   **`title_Master`**：是否是小男孩 (1/0)。
*   **`title_Miss`**：是否是未婚女性/女孩 (1/0)。
*   **`title_Mr`**：是否是成年男性 (1/0)。
*   **`title_Mrs`**：是否是已婚女性 (1/0)。
*   **`title_rare`**：是否是稀有头衔（如 Dr, Rev, Sir 等） (1/0)。

---
**注意**：原始特征如 `Age`, `Fare`, `SibSp`, `Parch`, `Ticket`, `Name` 等在构建完上述特征后，并未直接放入最终模型中训练。